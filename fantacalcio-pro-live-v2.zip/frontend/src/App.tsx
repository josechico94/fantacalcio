
import React, { useEffect, useState } from "react";
const API = import.meta.env.VITE_API_URL || "http://localhost:8000";
type Projection = { player_id:number; name:string; position:string; match_id:number; team:string; opponent:string; p_start:number; exp_goals:number; exp_assists:number; p_cs:number; exp_points:number; };

function Projections() {
  const [matchday, setMatchday] = useState(9);
  const [role, setRole] = useState<string | "">("");  
  const [rows, setRows] = useState<Projection[]>([]);
  useEffect(() => { const url = new URL(API + "/projections"); url.searchParams.set("matchday", String(matchday)); if (role) url.searchParams.set("role", role);
    fetch(url.toString()).then(r => r.json()).then(d => setRows(d.projections || [])).catch(()=>setRows([])); }, [matchday, role]);
  return (<div>
    <h2>Proyecciones</h2>
    <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:12 }}>
      <label>Jornada</label><select value={matchday} onChange={e=>setMatchday(Number(e.target.value))}>{Array.from({length:38},(_,i)=>i+1).map(n=>(<option key={n} value={n}>{n}</option>))}</select>
      <label>Rol</label><select value={role || 'all'} onChange={e=>setRole(e.target.value==='all' ? '' : e.target.value)}>
        <option value='all'>Todos</option><option value='GK'>GK</option><option value='DEF'>DEF</option><option value='MID'>MID</option><option value='FWD'>FWD</option>
      </select>
    </div>
    <table style={{ width:'100%', borderCollapse:'collapse' }}><thead><tr style={{ borderBottom:'1px solid #ddd' }}>
      <th>Jugador</th><th>Rol</th><th>Equipo</th><th>Rival</th><th>pTitular</th><th>xG</th><th>xA</th><th>pCS</th><th>Puntos exp.</th></tr></thead>
      <tbody>{rows.map(r => (<tr key={`${r.match_id}-${r.player_id}`} style={{ borderBottom:'1px solid #eee' }}>
        <td>{r.name}</td><td>{r.position}</td><td>{r.team}</td><td>{r.opponent}</td><td>{Math.round(r.p_start*100)}%</td>
        <td>{r.exp_goals.toFixed(2)}</td><td>{r.exp_assists.toFixed(2)}</td><td>{Math.round(r.p_cs*100)}%</td><td><b>{r.exp_points.toFixed(2)}</b></td>
      </tr>))}</tbody></table>
  </div>);
}

function Compare() {
  const [list, setList] = useState<{id:number;name:string}[]>([]);
  const [a, setA] = useState<number | ''>('');
  const [b, setB] = useState<number | ''>('');
  const [data, setData] = useState<any | null>(null);

  useEffect(()=>{
    fetch(API + "/players").then(r=>r.json()).then(d=>setList((d.players||[]).map((p:any)=>({id:p.id,name:p.name}))));
  },[]);

  const canCompare = typeof a==='number' && typeof b==='number' && a!==b;

  async function runCompare(){
    if(!canCompare) return;
    const url = new URL(API + "/compare");
    url.searchParams.set("a", String(a)); url.searchParams.set("b", String(b));
    const res = await fetch(url.toString()).then(r=>r.json());
    setData(res);
  }

  return (<div>
    <h2>Comparar jugadores</h2>
    <div style={{ display:'flex', gap:8, marginBottom:12 }}>
      <select value={a||''} onChange={e=>setA(Number(e.target.value))}><option value=''>Jugador A</option>{list.map(p=>(<option key={p.id} value={p.id}>{p.name}</option>))}</select>
      <select value={b||''} onChange={e=>setB(Number(e.target.value))}><option value=''>Jugador B</option>{list.map(p=>(<option key={p.id} value={p.id}>{p.name}</option>))}</select>
      <button onClick={runCompare} disabled={!canCompare}>Comparar</button>
    </div>
    {data && (<table style={{ width:'100%', borderCollapse:'collapse' }}>
      <thead><tr><th></th><th>Equipo</th><th>Posición</th><th>Partidos (temp)</th><th>Goles</th><th>Asistencias</th><th>Tiros</th><th>Minutos</th></tr></thead>
      <tbody>
        <tr><td><b>{data.a.name}</b></td><td>{data.a.team}</td><td>{data.a.position}</td><td>{data.a.season_games ?? '-'}</td><td>{data.a.goals ?? '-'}</td><td>{data.a.assists ?? '-'}</td><td>{data.a.shots ?? '-'}</td><td>{data.a.minutes ?? '-'}</td></tr>
        <tr><td><b>{data.b.name}</b></td><td>{data.b.team}</td><td>{data.b.position}</td><td>{data.b.season_games ?? '-'}</td><td>{data.b.goals ?? '-'}</td><td>{data.b.assists ?? '-'}</td><td>{data.b.shots ?? '-'}</td><td>{data.b.minutes ?? '-'}</td></tr>
      </tbody>
    </table>)}
  </div>);
}

export default function App(){
  const [tab, setTab] = useState<'proj'|'comp'>('proj');
  return (<div style={{ maxWidth: 1100, margin:'0 auto', padding:16 }}>
    <h1>Fantacalcio Live v2</h1>
    <div style={{ display:'flex', gap:8, marginBottom:16 }}>
      <button onClick={()=>setTab('proj')} disabled={tab==='proj'}>Proyecciones</button>
      <button onClick={()=>setTab('comp')} disabled={tab==='comp'}>Comparador</button>
    </div>
    {tab==='proj' ? <Projections/> : <Compare/>}
  </div>);
}
