
from app.db import SessionLocal, Base, engine
from app.models import TeamRatings
from app.config import settings

def main(season: int | None = None, window: int = 5):
    season = season or settings.default_season
    db = SessionLocal()
    # Compute GF/GA per team over last `window` fixtures with results present
    # Using matches table; relies on API fixtures that include score in JSON stored? We didn't store scores, so we query API each time would be better.
    # For simplicity, derive from fixture ext ids via API on the fly.
    from app.services.api_football_client import APIFootballClient
    api = APIFootballClient()
    league = settings.league_id
    fixtures = api.fixtures(league=league, season=season)
    # Build per-team recent list
    from collections import defaultdict, deque
    hist = defaultdict(lambda: deque(maxlen=window))
    for fx in fixtures:
        teams = fx.get("teams", {})
        home = teams.get("home", {}) or {}
        away = teams.get("away", {}) or {}
        score = (fx.get("goals", {}) or {})
        gh, ga = score.get("home", 0) or 0, score.get("away", 0) or 0
        if home.get("id") and away.get("id"):
            hist[str(home["id"])].append((gh, ga))
            hist[str(away["id"])].append((ga, gh))
    # Upsert ratings
    for team_ext, arr in hist.items():
        if not arr: continue
        gf = sum(x for x,_ in arr); ga = sum(y for _,y in arr)
        n = len(arr)
        # map ext_id to internal team_id
        r = db.execute("SELECT id FROM teams WHERE ext_id=:e", {"e": str(team_ext)}).first()
        if not r: continue
        team_id = r[0]
        gf90 = gf / n
        ga90 = ga / n
        db.execute("""
INSERT INTO team_ratings(team_id, season, gf90, ga90)
VALUES (:t,:s,:gf,:ga)
ON CONFLICT(team_id, season) DO UPDATE SET gf90=excluded.gf90, ga90=excluded.ga90, updated_at=CURRENT_TIMESTAMP
""", {"t": team_id, "s": season, "gf": gf90, "ga": ga90})
    db.commit()
    print("Team ratings updated for season", season)

if __name__ == "__main__":
    main()
