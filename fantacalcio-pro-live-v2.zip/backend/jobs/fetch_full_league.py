
from app.db import SessionLocal, Base, engine
from app.models import Team, Player, Match
from app.config import settings
from app.services.api_football_client import APIFootballClient
from datetime import datetime

def upsert_team(db, ext_id, name, short):
    t = db.execute("SELECT id FROM teams WHERE ext_id=:e", {"e": ext_id}).first()
    if t: return t[0]
    db.execute("INSERT INTO teams(ext_id,name,short_name,created_at) VALUES (:e,:n,:s,:c)",
               {"e": ext_id, "n": name, "s": short, "c": datetime.utcnow()})
    db.commit()
    return db.execute("SELECT id FROM teams WHERE ext_id=:e", {"e": ext_id}).first()[0]

def upsert_player(db, ext_id, name, position, team_id):
    p = db.execute("SELECT id FROM players WHERE ext_id=:e", {"e": ext_id}).first()
    if p: return p[0]
    db.execute("INSERT INTO players(ext_id,name,position,team_id,created_at) VALUES (:e,:n,:pos,:t,:c)",
               {"e": ext_id, "n": name, "pos": position, "t": team_id, "c": datetime.utcnow()})
    db.commit()
    return db.execute("SELECT id FROM players WHERE ext_id=:e", {"e": ext_id}).first()[0]

def upsert_match(db, ext_id, season, matchday, kickoff, home_id, away_id, venue):
    m = db.execute("SELECT id FROM matches WHERE ext_id=:e", {"e": ext_id}).first()
    if m: return m[0]
    db.execute("""
INSERT INTO matches(ext_id,season,matchday,kickoff,home_team_id,away_team_id,venue,created_at)
VALUES (:e,:s,:md,:ko,:h,:a,:v,:c)
""",
        {"e": ext_id, "s": season, "md": matchday, "ko": kickoff, "h": home_id, "a": away_id, "v": venue, "c": datetime.utcnow()})
    db.commit()
    return db.execute("SELECT id FROM matches WHERE ext_id=:e", {"e": ext_id}).first()[0]

def main():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    api = APIFootballClient()
    league = settings.league_id
    season = settings.default_season

    for t in api.teams(league=league, season=season):
        team = t.get("team", {})
        ext = str(team.get("id"))
        name = team.get("name")
        short = team.get("code") or name[:3].upper()
        upsert_team(db, ext, name, short)

    page = 1
    while True:
        data = api.players(league=league, season=season, page=page)
        resp = data.get("response", [])
        if not resp: break
        for item in resp:
            player = item.get("player", {})
            statistics = item.get("statistics", [])
            pos = player.get("position") or (statistics[0].get("games",{}).get("position") if statistics else None) or "MID"
            team_ext = None
            if statistics:
                team_ext = str(statistics[0].get("team", {}).get("id"))
            if not team_ext: continue
            r = db.execute("SELECT id FROM teams WHERE ext_id=:e", {"e": team_ext}).first()
            if not r: continue
            team_id = r[0]
            upsert_player(db, str(player.get("id")), player.get("name"), pos[:3].upper(), team_id)
        page += 1
        if page > (data.get("paging", {}).get("total", 1)): break

    for fx in api.fixtures(league=league, season=season):
        f = fx.get("fixture", {})
        ext = str(f.get("id"))
        date = f.get("date")
        venue = (f.get("venue", {}) or {}).get("name") or ""
        league_info = fx.get("league", {})
        matchday = league_info.get("round") or "Regular Season - 1"
        md_num = 1
        try:
            md_num = int(str(matchday).split("-")[-1].strip())
        except:
            pass
        teams = fx.get("teams", {})
        home_ext = str((teams.get("home", {}) or {}).get("id"))
        away_ext = str((teams.get("away", {}) or {}).get("id"))
        h = db.execute("SELECT id FROM teams WHERE ext_id=:e", {"e": home_ext}).first()
        a = db.execute("SELECT id FROM teams WHERE ext_id=:e", {"e": away_ext}).first()
        if not h or not a: continue
        upsert_match(db, ext, season, md_num, date, h[0], a[0], venue)

    print("Ingest complete: teams, players, fixtures")

if __name__ == "__main__":
    main()
