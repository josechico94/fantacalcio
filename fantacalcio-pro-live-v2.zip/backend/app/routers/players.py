
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from ..db import SessionLocal
router = APIRouter()
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()
@router.get("")
def list_players(q: str | None = Query(None), db: Session = Depends(get_db)):
    rows = db.execute("SELECT p.id, p.name, p.position, t.short_name as team FROM players p LEFT JOIN teams t ON p.team_id=t.id").mappings().all()
    data = [dict(r) for r in rows]
    if q: data = [d for d in data if q.lower() in d["name"].lower()]
    return {"players": data}
