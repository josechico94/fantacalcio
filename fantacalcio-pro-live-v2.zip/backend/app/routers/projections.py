
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from ..db import SessionLocal
from ..services.projection_service import project_matchday
from ..config import settings
router = APIRouter()
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()
@router.get("")
def get_projections(season: int | None = None, matchday: int = Query(..., ge=1, le=38), role: str | None = None, db: Session = Depends(get_db)):
    season = season or settings.default_season
    rows = project_matchday(db, season=season, matchday=matchday)
    if role: rows = [r for r in rows if r["position"] == role]
    return {"season": season, "matchday": matchday, "count": len(rows), "projections": rows}
