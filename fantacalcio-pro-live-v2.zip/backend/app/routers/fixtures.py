
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from ..db import SessionLocal
router = APIRouter()
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()
@router.get("")
def list_fixtures(season: int, matchday: int, db: Session = Depends(get_db)):
    rows = db.execute("SELECT id, season, matchday, kickoff, home_team_id, away_team_id, venue FROM matches WHERE season=:s AND matchday=:md",
                      {"s": season, "md": matchday}).mappings().all()
    return {"fixtures": [dict(r) for r in rows]}
