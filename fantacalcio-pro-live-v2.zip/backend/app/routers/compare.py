
from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from ..db import SessionLocal
from ..services.compare_service import get_player_stats
from ..config import settings
router = APIRouter()
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()
@router.get("")
def compare_players(a: int = Query(...), b: int = Query(...), season: int | None = None, db: Session = Depends(get_db)):
    A = get_player_stats(db, a, season); B = get_player_stats(db, b, season)
    if not A or not B: raise HTTPException(404, "One or both players not found")
    return {"a": A, "b": B}
