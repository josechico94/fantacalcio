
import os
from pydantic import BaseModel
from dotenv import load_dotenv
load_dotenv()
class Settings(BaseModel):
    app_name: str = "Serie A Fantacalcio API (Live v2)"
    debug: bool = os.getenv("DEBUG", "false").lower() == "true"
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./fantadb.sqlite3")
    api_football_key: str = os.getenv("API_FOOTBALL_KEY", "")
    league_id: int = int(os.getenv("LEAGUE_ID", "135"))
    default_season: int = int(os.getenv("DEFAULT_SEASON", "2025"))
    scoring_file: str = os.getenv("SCORING_FILE", "./config/scoring_fantacalcio_classic.json")
    requests_per_min: int = int(os.getenv("REQUESTS_PER_MIN", "50"))
settings = Settings()
