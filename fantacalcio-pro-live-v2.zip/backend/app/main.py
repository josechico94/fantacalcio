
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .db import Base, engine
from .routers import health, players, fixtures, projections, compare

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Serie A Fantacalcio API (Live v2)")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

app.include_router(health.router, tags=["health"])
app.include_router(players.router, prefix="/players", tags=["players"])
app.include_router(fixtures.router, prefix="/fixtures", tags=["fixtures"])
app.include_router(projections.router, prefix="/projections", tags=["projections"])
app.include_router(compare.router, prefix="/compare", tags=["compare"])

@app.get("/")
def root(): return {"ok": True}
