
import math
from typing import Dict, List
from sqlalchemy.orm import Session
from ..models import TeamRatings
from .scoring import get_scoring

def poisson_p0(lmbd: float) -> float:
    return math.exp(-max(lmbd, 0.0))

def project_player_row(p, team: str, opponent: str, p_cs: float) -> Dict:
    minutes_factor = max(min(p.get("minutes_expected", 75) / 90.0, 1.2), 0.0)
    l_goals = max(p.get("xg_per90", 0.1), 0.0) * minutes_factor
    l_ast = max(p.get("xa_per90", 0.1), 0.0) * minutes_factor

    scoring = get_scoring()
    goal_points = scoring["goal"].get(p["position"], 3)
    assist_points = scoring["assist"]
    cs_points = scoring["clean_sheet"].get(p["position"], 0)

    exp_points = p["p_start"] * (goal_points * l_goals + assist_points * l_ast + (cs_points if p['position'] in ('GK','DEF') else 0)* p_cs + 0.5 * minutes_factor)
    return {
        "player_id": p["player_id"], "name": p["name"], "position": p["position"], "match_id": p["match_id"],
        "team": team, "opponent": opponent, "p_start": round(p["p_start"], 3),
        "exp_goals": round(l_goals, 3), "exp_assists": round(l_ast, 3), "p_cs": round(p_cs, 3), "exp_points": round(exp_points, 3),
    }

def team_clean_sheet_prob(db: Session, season: int, team_id: int, opp_team_id: int) -> float:
    r1 = db.execute("SELECT gf90, ga90 FROM team_ratings WHERE season=:s AND team_id=:t", {"s": season, "t": opp_team_id}).first()
    r2 = db.execute("SELECT gf90, ga90 FROM team_ratings WHERE season=:s AND team_id=:t", {"s": season, "t": team_id}).first()
    if not r1 or not r2:
        return 0.25  # fallback
    opp_gf90 = float(r1[0] or 1.2)  # opponent scoring rate
    our_ga90 = float(r2[1] or 1.2)  # our conceded rate
    lam = max(0.05, (opp_gf90 + our_ga90) / 2.0)  # simple blend
    return poisson_p0(lam)

def project_matchday(db: Session, season: int, matchday: int) -> List[Dict]:
    matches = db.execute("SELECT id, home_team_id, away_team_id FROM matches WHERE season=:s AND matchday=:md", {"s": season, "md": matchday}).all()
    rows = []
    for m in matches:
        p_cs_home = team_clean_sheet_prob(db, season, m.home_team_id, m.away_team_id)
        p_cs_away = team_clean_sheet_prob(db, season, m.away_team_id, m.home_team_id)
        plist = db.execute(
            """
SELECT p.id as player_id, p.name, p.position, th.short_name as team, ta.short_name as opponent, p.team_id as team_id
FROM players p
JOIN teams th ON th.id = p.team_id
JOIN teams ta ON (CASE WHEN p.team_id = :t1 THEN :t2 ELSE :t1 END) = ta.id
WHERE p.team_id IN (:t1, :t2)
LIMIT 16
""",
            {"t1": m.home_team_id, "t2": m.away_team_id}
        ).all()
        for pl in plist:
            base = {
                "player_id": pl.player_id, "name": pl.name, "position": pl.position, "match_id": m.id,
                "xg_per90": 0.22 if pl.position != "GK" else 0.0,
                "xa_per90": 0.17 if pl.position in ("MID","DEF") else 0.08,
                "minutes_expected": 78 if pl.position != "FWD" else 72,
                "p_start": 0.84 if pl.position != "FWD" else 0.70,
            }
            pcs = p_cs_home if pl.team_id == m.home_team_id else p_cs_away
            rows.append(project_player_row(base, team=pl.team, opponent=pl.opponent, p_cs=pcs))
    rows.sort(key=lambda r: r["exp_points"], reverse=True)
    return rows
