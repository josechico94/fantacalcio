
import time, httpx
from typing import Any, Dict, Optional
from ..config import settings
API_URL = "https://v3.football.api-sports.io"
class APIFootballClient:
    def __init__(self, api_key: Optional[str] = None, rpm: int = 50):
        self.api_key = api_key or settings.api_football_key
        self._min_interval = 60.0 / max(rpm, 1)
        self._last = 0.0
        self.headers = {"x-apisports-key": self.api_key}
    def _throttle(self):
        import time as _t
        delta = _t.time() - self._last
        if delta < self._min_interval:
            _t.sleep(self._min_interval - delta)
        self._last = _t.time()
    def _get(self, path: str, params: Dict[str, Any]) -> Dict[str, Any]:
        self._throttle()
        with httpx.Client(timeout=30) as c:
            r = c.get(API_URL + path, headers=self.headers, params=params)
            r.raise_for_status()
            return r.json()
    def teams(self, league: int, season: int): return self._get("/teams", {"league": league, "season": season}).get("response", [])
    def players(self, league: int, season: int, page: int = 1): return self._get("/players", {"league": league, "season": season, "page": page})
    def fixtures(self, league: int, season: int): return self._get("/fixtures", {"league": league, "season": season}).get("response", [])
    def fixture_players(self, fixture_id: int): return self._get("/fixtures/players", {"fixture": fixture_id}).get("response", [])
    def player_by_id(self, player_id: int, season: int): return self._get("/players", {"id": player_id, "season": season}).get("response", [])
