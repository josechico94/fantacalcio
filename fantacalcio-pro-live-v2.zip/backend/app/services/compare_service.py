
from sqlalchemy.orm import Session
from ..config import settings
from ..services.api_football_client import APIFootballClient

def get_player_stats(db: Session, internal_id: int, season: int | None = None):
    season = season or settings.default_season
    row = db.execute("SELECT p.id, p.name, p.position, t.short_name AS team, p.ext_id FROM players p LEFT JOIN teams t ON t.id = p.team_id WHERE p.id=:id", {"id": internal_id}).mappings().first()
    if not row:
        return None
    client = APIFootballClient()
    try:
        resp = client.player_by_id(player_id=int(row["ext_id"]), season=season)
    except Exception:
        resp = []
    # Aggregate simple season stats
    games = goals = assists = shots = minutes = None
    if resp:
        st = resp[0].get("statistics", []) if isinstance(resp[0], dict) else []
        for s in st:
            g = s.get("games", {}) or {}
            sh = s.get("shots", {}) or {}
            gl = s.get("goals", {}) or {}
            games = (games or 0) + int(g.get("appearences") or g.get("appearances") or 0)
            minutes = (minutes or 0) + int(g.get("minutes") or 0)
            shots = (shots or 0) + int(sh.get("total") or 0)
            goals = (goals or 0) + int(gl.get("total") or 0)
            assists = (assists or 0) + int(gl.get("assists") or 0)
    return {
        "id": row["id"], "name": row["name"], "position": row["position"], "team": row["team"],
        "season_games": games, "goals": goals, "assists": assists, "shots": shots, "minutes": minutes,
    }
