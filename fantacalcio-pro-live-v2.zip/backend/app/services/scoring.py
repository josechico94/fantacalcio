
import json
from functools import lru_cache
from ..config import settings
@lru_cache(maxsize=1)
def get_scoring():
    with open(settings.scoring_file, "r", encoding="utf-8") as f:
        return json.load(f)
