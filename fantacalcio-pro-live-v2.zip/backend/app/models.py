
from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Boolean, Numeric, Date, Text, UniqueConstraint
from .db import Base
from datetime import datetime

class Team(Base):
    __tablename__ = "teams"
    id = Column(Integer, primary_key=True)
    ext_id = Column(String(32), unique=True, nullable=False)
    name = Column(Text, nullable=False)
    short_name = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

class Player(Base):
    __tablename__ = "players"
    id = Column(Integer, primary key=True)
    ext_id = Column(String(32), unique=True, nullable=False)  # provider id
    team_id = Column(Integer, ForeignKey("teams.id"))
    name = Column(Text, nullable=False)
    position = Column(String(3), nullable=False)  # GK/DEF/MID/FWD
    foot = Column(String(5))
    birthdate = Column(Date)
    created_at = Column(DateTime, default=datetime.utcnow)

class Match(Base):
    __tablename__ = "matches"
    id = Column(Integer, primary_key=True)
    ext_id = Column(String(32), unique=True, nullable=False)
    season = Column(Integer, nullable=False)
    matchday = Column(Integer, nullable=False)
    kickoff = Column(DateTime, nullable=False)
    home_team_id = Column(Integer, ForeignKey("teams.id"))
    away_team_id = Column(Integer, ForeignKey("teams.id"))
    venue = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

class Appearance(Base):
    __tablename__ = "appearances"
    match_id = Column(Integer, ForeignKey("matches.id"), primary_key=True)
    player_id = Column(Integer, ForeignKey("players.id"), primary_key=True)
    minutes = Column(Integer)
    starter = Column(Boolean)
    position = Column(String(3))
    rating_src = Column(Numeric(4,2))

class Event(Base):
    __tablename__ = "events"
    id = Column(Integer, primary_key=True, autoincrement=True)
    match_id = Column(Integer, ForeignKey("matches.id"))
    player_id = Column(Integer, ForeignKey("players.id"))
    minute = Column(Integer)
    type = Column(String(24))
    xg = Column(Numeric(5,3))
    xa = Column(Numeric(5,3))

class InjurySuspension(Base):
    __tablename__ = "injuries_suspensions"
    id = Column(Integer, primary_key=True, autoincrement=True)
    player_id = Column(Integer, ForeignKey("players.id"))
    type = Column(String(24))
    note = Column(Text)
    date_from = Column(Date)
    date_to = Column(Date)

class Projection(Base):
    __tablename__ = "projections"
    match_id = Column(Integer, ForeignKey("matches.id"), primary_key=True)
    player_id = Column(Integer, ForeignKey("players.id"), primary_key=True)
    p_start = Column(Numeric(5,3))
    exp_goals = Column(Numeric(5,3))
    exp_assists = Column(Numeric(5,3))
    p_cs = Column(Numeric(5,3))
    exp_saves = Column(Numeric(5,3))
    p_yellow = Column(Numeric(5,3))
    p_red = Column(Numeric(5,3))
    exp_points_default = Column(Numeric(6,3))
    ts = Column(DateTime, primary_key=True)

class TeamRatings(Base):
    __tablename__ = "team_ratings"
    team_id = Column(Integer, ForeignKey("teams.id"), primary_key=True)
    season = Column(Integer, primary_key=True)
    gf90 = Column(Numeric(5,3))  # goals for per 90 (rolling L5)
    ga90 = Column(Numeric(5,3))  # goals against per 90 (rolling L5)
    updated_at = Column(DateTime, default=datetime.utcnow)
    __table_args__ = (UniqueConstraint('team_id','season', name='uq_team_season'),)
