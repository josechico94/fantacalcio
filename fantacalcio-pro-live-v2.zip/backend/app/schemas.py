
from pydantic import BaseModel
class PlayerOut(BaseModel):
    id: int
    name: str
    position: str
    team: str | None = None
    class Config: from_attributes = True
class ProjectionOut(BaseModel):
    player_id: int; name: str; position: str; match_id: int; team: str; opponent: str
    p_start: float; exp_goals: float; exp_assists: float; p_cs: float; exp_points: float
class CompareOut(BaseModel):
    id: int; name: str; position: str; team: str | None
    season_games: int | None = None; goals: int | None = None; assists: int | None = None; shots: int | None = None; minutes: int | None = None
