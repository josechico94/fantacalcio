
# Fantacalcio Serie A — Live v2 (API-FOOTBALL)

Incluye:
- **Poisson CS** con ratings por equipo (gf90/ga90 últimos partidos).
- **Comparador A vs B** con stats de temporada en vivo (API-FOOTBALL).
- Ingesta completa de equipos/jugadores/fixtures.

## Paso a paso (Docker)
1) Levantar servicios:
```bash
docker compose up --build
```
2) Ingestar liga (equipos, jugadores, fixtures):
```bash
docker compose exec api bash -lc "python -m jobs.fetch_full_league"
```
3) Calcular ratings de equipos (gf90/ga90) para CS:
```bash
docker compose exec api bash -lc "python -m jobs.compute_team_ratings"
```
4) (Opcional) Enriquecer stats por fixture:
```bash
docker compose exec api bash -lc "python -m jobs.fetch_matchday_stats"
```
5) Probar API:
- `http://localhost:8000/health`
- `http://localhost:8000/players`
- `http://localhost:8000/projections?matchday=9`
- `http://localhost:8000/compare?a=<playerId>&b=<playerId>`

## Frontend
```bash
cd frontend
npm install
VITE_API_URL=http://localhost:8000 npm run dev
```
Verás pestañas **Proyecciones** y **Comparador**.

## Notas técnicas
- `team_ratings` se recalcula con `jobs.compute_team_ratings` a partir de los goles reales de los últimos partidos disponibles en la API.
- El comparador tira stats por **temporada** desde `/players?id=<ext_id>&season=<season>` y resume: partidos, goles, asistencias, tiros y minutos.
- Para producción: mover secretos a variables de entorno, añadir cache en disco/Redis y autenticar endpoints si hará falta.
